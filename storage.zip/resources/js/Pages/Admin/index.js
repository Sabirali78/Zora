export { default as Dashboard } from './Dashboard';
export { default as AllArticles } from './AllArticles';
export { default as CreateArticle } from './CreateArticle';
export { default as EditArticle } from './EditArticle';
export { default as AdminLogs } from './AdminLogs';
export { default as Moderators } from './Moderators';
export { default as ModeratorLogs } from './ModeratorLogs';