import AdminNavbar from '@/components/AdminNavbar';

export default AdminNavbar;